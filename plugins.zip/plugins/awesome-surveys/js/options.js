jQuery('document').ready(function($) {
  postboxes.add_postbox_toggles(pagenow);
})