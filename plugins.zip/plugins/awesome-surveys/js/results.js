jQuery(document).ready(function($) {
  $('#side-sortables').parent().remove()
  $('.wrap h2:first').remove()
})