<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wpvufind');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'inf4hhhpI9W-P-~@5 N_#WZEOh2wK]6-`Jd: U$z,@FI{@FL#c-W;!3rJ)TG1c|j');
define('SECURE_AUTH_KEY',  '=tFT:Fu9Lr}>B]g[U=sx>j++LSiM=Cs0l4*sW$`+J%I2Vzi-{ytd{p3@BAY< P?]');
define('LOGGED_IN_KEY',    'jC}&Nu3XG8C]>mx);*U*)INk+37+-[t[SKu9H>tZ#vD]>&J,!dqb/:6G8dZT4Fc ');
define('NONCE_KEY',        'w$qFv=;|V8RNM|M/f0!destf5cjK!2X!a7?fOFS~iy@%g$_4TLW%QSqSJ*pghttn');
define('AUTH_SALT',        'O2t,+Z::Z2ZNcV|IKO~Cr0%>lR|xakJ*hUFat=Q!jKKJ%|7Y3.$=+8QG9BkLX17H');
define('SECURE_AUTH_SALT', 'j@dfHjW-H7KDaVJ#a9)y48V:llV]T_[#.d&.o0e@!wuOyJ37|uP.Jm*6qCx,raIv');
define('LOGGED_IN_SALT',   '| )Un^~[M~oSO|=_ynpua@iL?/9qN1!!xjGl%)nclsbNVE4*e}0-(tg%2}T |b?V');
define('NONCE_SALT',       'j2ZNT({%|nvR7@9iJ_k{|Kar3jZDsj7jSA|d=uJE,[x0|M;-fnd4Htni|j4+:O-X');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
